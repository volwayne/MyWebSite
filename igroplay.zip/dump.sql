--
-- PostgreSQL database dump
--

\restrict Dm0tqOZhNVep6v8jcmVoxr2sBfvLOTXTzG4qi41hootyBJm9LJZ94CMGd8w9I2O

-- Dumped from database version 18.3
-- Dumped by pg_dump version 18.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: games; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.games (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    category character varying(100),
    image_url text,
    plays integer DEFAULT 0,
    rating numeric(3,2) DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    file_path text,
    thumbnail text,
    width integer DEFAULT 800,
    height integer DEFAULT 600,
    zip_file text DEFAULT ''::text
);


ALTER TABLE public.games OWNER TO postgres;

--
-- Name: games_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.games_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.games_id_seq OWNER TO postgres;

--
-- Name: games_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.games_id_seq OWNED BY public.games.id;


--
-- Name: site_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.site_config (
    id integer NOT NULL,
    site_name character varying(255) DEFAULT 'igroplay.ru'::character varying,
    site_logo text DEFAULT ''::text,
    site_icon text DEFAULT ''::text,
    footer_text text DEFAULT 'Лучший каталог браузерных игр. Играй бесплатно онлайн!'::text,
    footer_copyright character varying(255) DEFAULT '© 2024 igroplay.ru. Все права защищены.'::character varying,
    footer_links text DEFAULT '[]'::text,
    meta_title character varying(255) DEFAULT 'Игры онлайн'::character varying,
    meta_description text DEFAULT 'Лучшие браузерные игры онлайн'::text,
    meta_keywords text DEFAULT 'игры, онлайн, бесплатно, webgl'::text,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    logo_html text DEFAULT '<div class="header-logo-icon"><i class="fas fa-gamepad"></i></div><div class="header-logo-text">igro<span>play</span></div>'::text,
    footer_logo_html text DEFAULT '<h3>igro<span>play</span></h3>'::text
);


ALTER TABLE public.site_config OWNER TO postgres;

--
-- Name: site_config_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.site_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.site_config_id_seq OWNER TO postgres;

--
-- Name: site_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.site_config_id_seq OWNED BY public.site_config.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    password character varying(255) NOT NULL,
    email character varying(255),
    role character varying(50) DEFAULT 'user'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    avatar text DEFAULT ''::text,
    balance integer DEFAULT 100
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: games id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.games ALTER COLUMN id SET DEFAULT nextval('public.games_id_seq'::regclass);


--
-- Name: site_config id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.site_config ALTER COLUMN id SET DEFAULT nextval('public.site_config_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: games; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.games (id, title, description, category, image_url, plays, rating, created_at, updated_at, file_path, thumbnail, width, height, zip_file) FROM stdin;
18	Test		arcade	/static/images/games/game_1774265070.png	0	0.00	2026-03-23 14:24:31.05721	2026-03-23 14:24:31.05721	games/game_1774265070/index.html	/static/images/games/game_1774265070.png	800	600	test.zip
56	Cascsacsa		puzzle	/static/images/games/game_1774333698.png	29	0.00	2026-03-24 09:28:18.405297	2026-03-24 17:10:08.761582	games/game_1774333698/index.html	/static/images/games/game_1774333698.png	0	0	12dda.zip
57	sxasxsa		strategy	/static/images/games/game_1774356343.png	71	0.00	2026-03-24 15:45:43.385741	2026-03-24 17:11:37.14036	games/game_1774356343/index.html	/static/images/games/game_1774356343.png	0	0	asasda.zip
58	xasxsaxa		action	/static/images/games/game_1774367140.png	2	0.00	2026-03-24 18:45:40.654486	2026-03-24 18:46:04.461778	games/game_1774367140/index.html	/static/images/games/game_1774367140.png	0	0	asdsad.zip
\.


--
-- Data for Name: site_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.site_config (id, site_name, site_logo, site_icon, footer_text, footer_copyright, footer_links, meta_title, meta_description, meta_keywords, updated_at, logo_html, footer_logo_html) FROM stdin;
1	IgroPlay.Ru	/static/images/logo.png	/static/images/favicon.ico	Играй бесплатно онлайн.	© 2026 IgroPlay.Ru. Все права защищены.	[\n        {"name":"Политика конфиденциальности","url":"#"},\n        {"name":"Пользовательское соглашение","url":"#"},\n        {"name":"Cookies","url":"#"}\n    ]	Игры онлайн	Лучшие браузерные игры онлайн	игры, онлайн, бесплатно, webgl	2026-03-24 15:03:24.980579	<div class="header-logo-icon"><i class="fas fa-gamepad"></i></div><div class="header-logo-text">Igro<span>Play</span></div>	<h3>Igro<span>Play</span></h3>
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password, email, role, created_at, avatar, balance) FROM stdin;
2	user	$2a$10$vxXJbHlp7mfDQaCgbBU9HOQxycs4MfVIVNVtk9uaZCR5s0aAtpWdi		user	2026-03-21 21:58:07.948961		100
1	admin	$2a$10$.g0tnZ5kytb91KpCzP9zP.NjSZsUGTZJ/3GZmhNgKo1rgLW8joxXi		admin	2026-03-21 21:57:34.656749		600
\.


--
-- Name: games_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.games_id_seq', 58, true);


--
-- Name: site_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.site_config_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: games games_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.games
    ADD CONSTRAINT games_pkey PRIMARY KEY (id);


--
-- Name: site_config site_config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.site_config
    ADD CONSTRAINT site_config_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- PostgreSQL database dump complete
--

\unrestrict Dm0tqOZhNVep6v8jcmVoxr2sBfvLOTXTzG4qi41hootyBJm9LJZ94CMGd8w9I2O

