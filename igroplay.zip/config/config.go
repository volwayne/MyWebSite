package config

import (
    "fmt"
    "log"
    "os"
    "strconv"
    "strings"

    "github.com/joho/godotenv"
)

type AppConfig struct {
    DBHost       string
    DBPort       int
    DBUser       string
    DBPassword   string
    DBName       string
    SSLMode      string
    ServerPort   string
    SessionSecret string
}

func LoadAppConfig() *AppConfig {
    // Загружаем .env файл
    if err := godotenv.Load(); err != nil {
        log.Println("⚠️  No .env file found, using environment variables")
    }

    dbPort, _ := strconv.Atoi(getEnv("DB_PORT", "5432"))

    cfg := &AppConfig{
        DBHost:        getEnv("DB_HOST", "localhost"),
        DBPort:        dbPort,
        DBUser:        getEnv("DB_USER", "postgres"),
        DBPassword:    getEnv("DB_PASSWORD", ""),
        DBName:        getEnv("DB_NAME", "games_portal"),
        SSLMode:       getEnv("SSL_MODE", "disable"),
        ServerPort:    getEnv("SERVER_PORT", "8080"),
        SessionSecret: getEnv("SESSION_SECRET", "default-secret-key-change-me"),
    }

    if cfg.DBPassword == "" {
        log.Println("⚠️  WARNING: DB_PASSWORD is not set in .env file")
    }

    return cfg
}

func (c *AppConfig) GetPostgresConnectionString() string {
    connStr := fmt.Sprintf(
        "host=%s port=%d user=%s password=%s dbname=%s sslmode=%s",
        c.DBHost, c.DBPort, c.DBUser, c.DBPassword, c.DBName, c.SSLMode,
    )
    
    if strings.Contains(strings.ToLower(os.Getenv("OS")), "windows") {
        connStr += " connect_timeout=10"
    }
    
    return connStr
}

func getEnv(key, defaultValue string) string {
    if value := os.Getenv(key); value != "" {
        return value
    }
    return defaultValue
}