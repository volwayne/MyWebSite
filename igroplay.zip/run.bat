@echo off
echo ========================================
echo   Browser Games Portal
echo   Starting server...
echo ========================================

:: Проверяем наличие Go
where go >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Go is not installed or not in PATH
    echo Please install Go from https://golang.org/dl/
    pause
    exit /b 1
)

:: Проверяем наличие .env файла
if not exist .env (
    echo [WARNING] .env file not found!
    echo Creating default .env file...
    (
        echo DB_HOST=localhost
        echo DB_PORT=5432
        echo DB_USER=postgres
        echo DB_PASSWORD=postgres
        echo DB_NAME=playre
        echo SSL_MODE=disable
        echo SERVER_PORT=8080
        echo SESSION_SECRET=your-super-secret-session-key-change-this
    ) > .env
    echo [OK] .env file created. Please edit it with your PostgreSQL credentials.
    pause
)

:: Устанавливаем зависимости
echo Installing dependencies...
go mod tidy

:: Запускаем приложение
echo.
echo Starting application...
echo Press Ctrl+C to stop
echo.
go run main.go

pause