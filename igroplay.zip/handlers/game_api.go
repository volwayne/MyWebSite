package handlers

import (
    "browser-games-portal/models"
    "net/http"
    "strconv"
    
    "github.com/gin-contrib/sessions"
    "github.com/gin-gonic/gin"
)

// GameAPI - API для взаимодействия игры с сайтом
type GameAPI struct {
    repo *models.GameRepository
}

func NewGameAPI(repo *models.GameRepository) *GameAPI {
    return &GameAPI{repo: repo}
}

// ============================================
// USER INFO
// ============================================

// GetUserInfo - получить информацию о пользователе
func (api *GameAPI) GetUserInfo(c *gin.Context) {
    session := sessions.Default(c)
    userID := session.Get("user_id")
    
    if userID == nil {
        c.JSON(http.StatusUnauthorized, gin.H{
            "success": false,
            "error":   "User not logged in",
        })
        return
    }
    
    user, err := api.repo.GetUserByID(userID.(int))
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{
            "success": false,
            "error":   "User not found",
        })
        return
    }
    
    c.JSON(http.StatusOK, gin.H{
        "success": true,
        "user": gin.H{
            "id":       user.ID,
            "username": user.Username,
            "email":    user.Email,
            "balance":  user.Balance,
            "role":     user.Role,
        },
    })
}

// ============================================
// BALANCE OPERATIONS
// ============================================

// AddBalance - добавить баланс (за достижения в игре)
func (api *GameAPI) AddBalance(c *gin.Context) {
    session := sessions.Default(c)
    userID := session.Get("user_id")
    
    if userID == nil {
        c.JSON(http.StatusUnauthorized, gin.H{
            "success": false,
            "error":   "User not logged in",
        })
        return
    }
    
    var req struct {
        Amount int    `json:"amount"`
        Reason string `json:"reason"`
    }
    
    if err := c.BindJSON(&req); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{
            "success": false,
            "error":   "Invalid request",
        })
        return
    }
    
    if req.Amount <= 0 {
        c.JSON(http.StatusBadRequest, gin.H{
            "success": false,
            "error":   "Amount must be positive",
        })
        return
    }
    
    err := api.repo.AddToUserBalance(userID.(int), req.Amount)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{
            "success": false,
            "error":   "Failed to add balance",
        })
        return
    }
    
    user, _ := api.repo.GetUserByID(userID.(int))
    
    c.JSON(http.StatusOK, gin.H{
        "success":    true,
        "newBalance": user.Balance,
        "message":    "Added " + strconv.Itoa(req.Amount) + " credits for: " + req.Reason,
    })
}

// SpendBalance - потратить баланс (за внутриигровые покупки)
func (api *GameAPI) SpendBalance(c *gin.Context) {
    session := sessions.Default(c)
    userID := session.Get("user_id")
    
    if userID == nil {
        c.JSON(http.StatusUnauthorized, gin.H{
            "success": false,
            "error":   "User not logged in",
        })
        return
    }
    
    var req struct {
        Amount int    `json:"amount"`
        Item   string `json:"item"`
        ItemID string `json:"item_id"`
    }
    
    if err := c.BindJSON(&req); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{
            "success": false,
            "error":   "Invalid request",
        })
        return
    }
    
    if req.Amount <= 0 {
        c.JSON(http.StatusBadRequest, gin.H{
            "success": false,
            "error":   "Amount must be positive",
        })
        return
    }
    
    user, err := api.repo.GetUserByID(userID.(int))
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{
            "success": false,
            "error":   "User not found",
        })
        return
    }
    
    // Проверяем, достаточно ли средств
    if user.Balance < req.Amount {
        c.JSON(http.StatusBadRequest, gin.H{
            "success": false,
            "error":   "Insufficient balance",
            "balance": user.Balance,
            "needed":  req.Amount,
        })
        return
    }
    
    newBalance := user.Balance - req.Amount
    err = api.repo.UpdateUserBalance(userID.(int), newBalance)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{
            "success": false,
            "error":   "Failed to update balance",
        })
        return
    }
    
    c.JSON(http.StatusOK, gin.H{
        "success":    true,
        "newBalance": newBalance,
        "message":    "Spent " + strconv.Itoa(req.Amount) + " credits for: " + req.Item,
        "item":       req.Item,
        "itemId":     req.ItemID,
    })
}

// ============================================
// ADVERTISEMENT
// ============================================

// ShowRewardedAd - показать рекламный ролик за награду
func (api *GameAPI) ShowRewardedAd(c *gin.Context) {
    session := sessions.Default(c)
    userID := session.Get("user_id")
    
    if userID == nil {
        c.JSON(http.StatusUnauthorized, gin.H{
            "success": false,
            "error":   "User not logged in",
        })
        return
    }
    
    // Здесь можно интегрировать реальную рекламную сеть
    // Пока просто выдаем награду
    reward := 50 // стандартная награда за просмотр рекламы
    
    err := api.repo.AddToUserBalance(userID.(int), reward)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{
            "success": false,
            "error":   "Failed to add reward",
        })
        return
    }
    
    user, _ := api.repo.GetUserByID(userID.(int))
    
    c.JSON(http.StatusOK, gin.H{
        "success":    true,
        "reward":     reward,
        "newBalance": user.Balance,
        "message":    "Thanks for watching! You earned " + strconv.Itoa(reward) + " credits!",
    })
}

// ============================================
// GAME PROGRESS
// ============================================

// SaveGameProgress - сохранить прогресс игры
func (api *GameAPI) SaveGameProgress(c *gin.Context) {
    session := sessions.Default(c)
    userID := session.Get("user_id")
    
    if userID == nil {
        c.JSON(http.StatusUnauthorized, gin.H{
            "success": false,
            "error":   "User not logged in",
        })
        return
    }
    
    var req struct {
        GameID   int                    `json:"game_id"`
        Progress map[string]interface{} `json:"progress"`
    }
    
    if err := c.BindJSON(&req); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{
            "success": false,
            "error":   "Invalid request",
        })
        return
    }
    
    // Здесь сохраняем прогресс в базу данных
    // Пока просто имитируем успех
    _ = req.GameID
    _ = req.Progress
    
    c.JSON(http.StatusOK, gin.H{
        "success": true,
        "message": "Progress saved successfully",
    })
}

// LoadGameProgress - загрузить прогресс игры
func (api *GameAPI) LoadGameProgress(c *gin.Context) {
    session := sessions.Default(c)
    userID := session.Get("user_id")
    
    if userID == nil {
        c.JSON(http.StatusUnauthorized, gin.H{
            "success": false,
            "error":   "User not logged in",
        })
        return
    }
    
    gameID, err := strconv.Atoi(c.Param("id"))
    if err != nil {
        c.JSON(http.StatusBadRequest, gin.H{
            "success": false,
            "error":   "Invalid game ID",
        })
        return
    }
    
    // Здесь загружаем прогресс из базы данных
    // Пока возвращаем пустой прогресс
    _ = gameID
    
    c.JSON(http.StatusOK, gin.H{
        "success":  true,
        "progress": map[string]interface{}{},
    })
}

// ============================================
// LEADERBOARD
// ============================================

// GetLeaderboard - получить таблицу лидеров
func (api *GameAPI) GetLeaderboard(c *gin.Context) {
    gameID, err := strconv.Atoi(c.Param("id"))
    if err != nil {
        c.JSON(http.StatusBadRequest, gin.H{
            "success": false,
            "error":   "Invalid game ID",
        })
        return
    }
    
    // Здесь получаем лидерборд из базы данных
    // Пока возвращаем пустой список
    _ = gameID
    
    c.JSON(http.StatusOK, gin.H{
        "success": true,
        "scores":  []interface{}{},
    })
}

// SubmitScore - отправить результат в лидерборд
func (api *GameAPI) SubmitScore(c *gin.Context) {
    session := sessions.Default(c)
    userID := session.Get("user_id")
    
    if userID == nil {
        c.JSON(http.StatusUnauthorized, gin.H{
            "success": false,
            "error":   "User not logged in",
        })
        return
    }
    
    var req struct {
        GameID int `json:"game_id"`
        Score  int `json:"score"`
    }
    
    if err := c.BindJSON(&req); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{
            "success": false,
            "error":   "Invalid request",
        })
        return
    }
    
    // Здесь сохраняем результат в лидерборд
    _ = req.GameID
    _ = req.Score
    
    c.JSON(http.StatusOK, gin.H{
        "success": true,
        "message": "Score submitted successfully",
    })
}