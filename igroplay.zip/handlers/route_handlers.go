package handlers

import (
    "archive/zip"
    "browser-games-portal/models"
    "fmt"
    "io"
    "log"
    "math/rand"
    "net/http"
    "os"
    "path/filepath"
    "strconv"
    "strings"
    "time"
	"html/template"
    
    "github.com/gin-contrib/sessions"
    "github.com/gin-gonic/gin"
    "golang.org/x/crypto/bcrypt"
)

type GamePortalHandler struct {
    repo *models.GameRepository
}

func NewGamePortalHandler(repo *models.GameRepository) *GamePortalHandler {
    rand.Seed(time.Now().UnixNano())
    return &GamePortalHandler{repo: repo}
}

// ============================================
// MIDDLEWARES
// ============================================

func (h *GamePortalHandler) AuthRequiredMiddleware() gin.HandlerFunc {
    return func(c *gin.Context) {
        session := sessions.Default(c)
        userID := session.Get("user_id")
        if userID == nil {
            c.Redirect(http.StatusFound, "/")
            c.Abort()
            return
        }
        c.Next()
    }
}

func (h *GamePortalHandler) AdminRequiredMiddleware() gin.HandlerFunc {
    return func(c *gin.Context) {
        session := sessions.Default(c)
        role := session.Get("role")
        if role != "admin" {
            c.HTML(http.StatusForbidden, "error_page.html", gin.H{
                "error": "Доступ запрещен. Требуются права администратора.",
            })
            c.Abort()
            return
        }
        c.Next()
    }
}

func (h *GamePortalHandler) GameAccessMiddleware() gin.HandlerFunc {
    return func(c *gin.Context) {
        filePath := c.Request.URL.Path
        
        // Если это не запрос к папке games, пропускаем
        if !strings.Contains(filePath, "/static/games/") {
            c.Next()
            return
        }
        
        // Получаем имя папки игры из URL
        parts := strings.Split(filePath, "/")
        var gameFolder string
        for i, part := range parts {
            if part == "games" && i+1 < len(parts) {
                gameFolder = parts[i+1]
                break
            }
        }
        
        // Проверяем сессию
        session := sessions.Default(c)
        allowedGame := session.Get("allowed_game")
        
        // Если в сессии нет разрешенной игры или это другая игра, блокируем
        if allowedGame == nil || allowedGame != gameFolder {
            c.AbortWithStatus(http.StatusNotFound)
            return
        }
        
        c.Next()
    }
}

// ============================================
// RENDER PAGE WITH COMMON COMPONENTS
// ============================================

func (h *GamePortalHandler) renderPage(c *gin.Context, templateName string, data gin.H) {
    session := sessions.Default(c)
    isAuthenticated := session.Get("user_id") != nil
    username := ""
    role := ""
    balance := 0
    userID := 0
    
    if isAuthenticated {
        if u, ok := session.Get("username").(string); ok {
            username = u
        }
        if r, ok := session.Get("role").(string); ok {
            role = r
        }
        if id, ok := session.Get("user_id").(int); ok {
            userID = id
            user, err := h.repo.GetUserByID(userID)
            if err == nil {
                balance = user.Balance
            }
        }
    }
    
    // Получаем конфигурацию сайта
    configRepo := models.NewConfigRepository(h.repo.DB)
    siteConfig, _ := configRepo.GetConfig()
    
    allGames, _, _ := h.repo.ListGames(models.GameFilter{Page: 1, PageSize: 1000})
    categoryMap := make(map[string]int)
    for _, game := range allGames {
        categoryMap[game.Category]++
    }
    
    categories := []map[string]interface{}{}
    categoryOrder := []string{"arcade", "strategy", "rpg", "action", "multiplayer", "board", "puzzle", "racing", "card", "horror"}
    for _, cat := range categoryOrder {
        if count, exists := categoryMap[cat]; exists {
            categories = append(categories, map[string]interface{}{
                "Name":        cat,
                "Count":       count,
                "DisplayName": getCategoryDisplayName(cat),
                "Icon":        getCategoryIcon(cat),
            })
        }
    }
    
    // Добавляем данные конфигурации (без логотипов)
    data["SiteName"] = siteConfig.SiteName
	data["LogoHTML"] = template.HTML(siteConfig.LogoHTML)
	data["FooterLogoHTML"] = template.HTML(siteConfig.FooterLogoHTML)
    data["FooterText"] = siteConfig.FooterText
    data["FooterCopyright"] = siteConfig.FooterCopyright
    data["MetaTitle"] = siteConfig.MetaTitle
    data["MetaDescription"] = siteConfig.MetaDescription
    data["MetaKeywords"] = siteConfig.MetaKeywords
    
    data["IsAuthenticated"] = isAuthenticated
    data["Username"] = username
    data["Role"] = role
    data["Balance"] = balance
    data["SearchQuery"] = c.Query("search")
    data["CurrentCategory"] = c.Query("category")
    data["TotalGames"] = len(allGames)
    data["Categories"] = categories
    data["LoginError"] = ""
    data["UserGamesPlayed"] = 0
    data["UserAvgRating"] = "0.0"
    data["ContentTemplate"] = templateName
    
    if _, ok := data["Title"]; !ok {
        data["Title"] = siteConfig.SiteName
    }
    if _, ok := data["ActivePage"]; !ok {
        data["ActivePage"] = "home"
    }
    
    c.HTML(http.StatusOK, "layout.html", data)
}

// ============================================
// PUBLIC PAGE HANDLERS
// ============================================

func (h *GamePortalHandler) ShowHomePage(c *gin.Context) {
    page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
    category := c.Query("category")
    search := c.Query("search")
    sortBy := c.DefaultQuery("sort", "newest")
    errorParam := c.Query("error")
    
    if page < 1 {
        page = 1
    }
    
    filter := models.GameFilter{
        Category: category,
        Search:   search,
        SortBy:   sortBy,
        Page:     page,
        PageSize: 12,
    }
    
    games, total, err := h.repo.ListGames(filter)
    if err != nil {
        c.HTML(http.StatusInternalServerError, "error_page.html", gin.H{
            "error": err.Error(),
        })
        return
    }
    
    totalPages := (total + filter.PageSize - 1) / filter.PageSize
    
    var loginError string
    switch errorParam {
    case "invalid_credentials":
        loginError = "Неверное имя пользователя или пароль"
    case "server_error":
        loginError = "Ошибка сервера, попробуйте позже"
    case "empty_fields":
        loginError = "Заполните все поля"
    case "password_short":
        loginError = "Пароль должен содержать минимум 6 символов"
    case "username_exists":
        loginError = "Пользователь с таким именем уже существует"
    }
    
    h.renderPage(c, "home_page.html", gin.H{
        "Title":       "Главная",
        "ActivePage":  "home",
        "Games":       games,
        "CurrentPage": page,
        "TotalPages":  totalPages,
        "Category":    category,
        "Search":      search,
        "SortBy":      sortBy,
        "LoginError":  loginError,
    })
}

func (h *GamePortalHandler) ShowGameDetail(c *gin.Context) {
    id, err := strconv.Atoi(c.Param("id"))
    if err != nil {
        c.HTML(http.StatusNotFound, "error_page.html", gin.H{
            "error": "Игра не найдена",
        })
        return
    }
    
    game, err := h.repo.GetGameByID(id)
    if err != nil {
        c.HTML(http.StatusNotFound, "error_page.html", gin.H{
            "error": "Игра не найдена",
        })
        return
    }
    
    // Получаем имя папки игры
    gamePath := game.FilePath
    parts := strings.Split(gamePath, "/")
    var gameFolder string
    if len(parts) >= 2 {
        gameFolder = parts[1]
    }
    
    // Сохраняем разрешение в сессию
    session := sessions.Default(c)
    session.Set("allowed_game", gameFolder)
    session.Save()
    
    h.renderPage(c, "game_detail.html", gin.H{
        "Title":       game.Title,
        "Description": game.Description,
        "ImageURL":    game.ImageURL,
        "CurrentURL":  c.Request.URL.String(),
        "ActivePage":  "game",
        "Game":        game,
    })
}

func (h *GamePortalHandler) ShowDashboard(c *gin.Context) {
    session := sessions.Default(c)
    userIDInterface := session.Get("user_id")
    
    if userIDInterface == nil {
        c.Redirect(http.StatusFound, "/")
        return
    }
    
    userID, ok := userIDInterface.(int)
    if !ok {
        if userIDFloat, ok := userIDInterface.(float64); ok {
            userID = int(userIDFloat)
        } else {
            c.Redirect(http.StatusFound, "/")
            return
        }
    }
    
    user, err := h.repo.GetUserByID(userID)
    if err != nil {
        c.HTML(http.StatusInternalServerError, "error_page.html", gin.H{
            "error": "Пользователь не найден",
        })
        return
    }
    
    stats := map[string]interface{}{
        "TotalGamesPlayed": 0,
        "AvgRating":        "0.0",
        "TotalPlays":       0,
    }
    
    recentGames := []models.Game{}
    favoriteGames := []models.Game{}
    
    h.renderPage(c, "dashboard.html", gin.H{
        "Title":         "Дашборд",
        "ActivePage":    "dashboard",
        "User":          user,
        "Stats":         stats,
        "RecentGames":   recentGames,
        "FavoriteGames": favoriteGames,
    })
}

// ============================================
// REGISTRATION PAGE
// ============================================

func (h *GamePortalHandler) ShowRegisterPage(c *gin.Context) {
    h.renderPage(c, "register.html", gin.H{
        "Title":       "Регистрация",
        "ActivePage":  "register",
        "error":       c.Query("error"),
    })
}

// ============================================
// AUTHENTICATION HANDLERS
// ============================================

func (h *GamePortalHandler) HandleUserLogin(c *gin.Context) {
    username := c.PostForm("username")
    password := c.PostForm("password")
    
    user, err := h.repo.GetUserByUsername(username)
    if err != nil {
        c.Redirect(http.StatusFound, "/?error=invalid_credentials")
        return
    }
    
    err = bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(password))
    if err != nil {
        c.Redirect(http.StatusFound, "/?error=invalid_credentials")
        return
    }
    
    session := sessions.Default(c)
    session.Set("user_id", user.ID)
    session.Set("username", user.Username)
    session.Set("role", user.Role)
    session.Save()
    
    c.Redirect(http.StatusFound, "/")
}

func (h *GamePortalHandler) HandleUserRegistration(c *gin.Context) {
    username := c.PostForm("username")
    password := c.PostForm("password")
    email := c.PostForm("email")
    
    if username == "" || password == "" {
        c.Redirect(http.StatusFound, "/register?error=empty_fields")
        return
    }
    
    if len(password) < 6 {
        c.Redirect(http.StatusFound, "/register?error=password_short")
        return
    }
    
    hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
    if err != nil {
        c.Redirect(http.StatusFound, "/register?error=server_error")
        return
    }
    
    user := &models.User{
        Username: username,
        Password: string(hashedPassword),
        Email:    email,
        Avatar:   "",
        Balance:  100,
        Role:     "user",
    }
    
    err = h.repo.CreateUser(user)
    if err != nil {
        c.Redirect(http.StatusFound, "/register?error=username_exists")
        return
    }
    
    session := sessions.Default(c)
    session.Set("user_id", user.ID)
    session.Set("username", user.Username)
    session.Set("role", user.Role)
    session.Save()
    
    c.Redirect(http.StatusFound, "/")
}

func (h *GamePortalHandler) HandleUserLogout(c *gin.Context) {
    session := sessions.Default(c)
    session.Clear()
    session.Save()
    c.Redirect(http.StatusFound, "/")
}

// ============================================
// BALANCE HANDLERS
// ============================================

func (h *GamePortalHandler) ShowBalance(c *gin.Context) {
    session := sessions.Default(c)
    userIDInterface := session.Get("user_id")
    
    if userIDInterface == nil {
        c.Redirect(http.StatusFound, "/")
        return
    }
    
    userID, ok := userIDInterface.(int)
    if !ok {
        if userIDFloat, ok := userIDInterface.(float64); ok {
            userID = int(userIDFloat)
        } else {
            c.Redirect(http.StatusFound, "/")
            return
        }
    }
    
    user, err := h.repo.GetUserByID(userID)
    if err != nil {
        c.HTML(http.StatusInternalServerError, "error_page.html", gin.H{
            "error": "Пользователь не найден",
        })
        return
    }
    
    transactions := []map[string]interface{}{}
    
    h.renderPage(c, "balance.html", gin.H{
        "Title":        "Баланс",
        "ActivePage":   "balance",
        "User":         user,
        "Transactions": transactions,
    })
}

// ============================================
// ADMIN PANEL HANDLERS
// ============================================

func (h *GamePortalHandler) ShowAdminPanel(c *gin.Context) {
    games, _, err := h.repo.ListGames(models.GameFilter{
        Page:     1,
        PageSize: 100,
    })
    if err != nil {
        c.HTML(http.StatusInternalServerError, "error_page.html", gin.H{
            "error": err.Error(),
        })
        return
    }
    
    var totalUsers int
    err = h.repo.DB.QueryRow("SELECT COUNT(*) FROM users").Scan(&totalUsers)
    if err != nil {
        totalUsers = 0
    }
    
    var totalPlays int
    err = h.repo.DB.QueryRow("SELECT COALESCE(SUM(plays), 0) FROM games").Scan(&totalPlays)
    if err != nil {
        totalPlays = 0
    }
    
    h.renderPage(c, "admin_panel.html", gin.H{
        "Title":      "Админ-панель",
        "ActivePage": "admin",
        "Games":      games,
        "TotalGames": len(games),
        "TotalUsers": totalUsers,
        "TotalPlays": totalPlays,
    })
}

func (h *GamePortalHandler) ShowAddGameForm(c *gin.Context) {
    h.renderPage(c, "admin_add_game.html", gin.H{
        "Title":      "Добавить игру",
        "ActivePage": "admin",
    })
}

func (h *GamePortalHandler) ShowEditGameForm(c *gin.Context) {
    id, err := strconv.Atoi(c.Param("id"))
    if err != nil {
        c.HTML(http.StatusNotFound, "error_page.html", gin.H{
            "error": "Игра не найдена",
        })
        return
    }
    
    game, err := h.repo.GetGameByID(id)
    if err != nil {
        c.HTML(http.StatusNotFound, "error_page.html", gin.H{
            "error": "Игра не найдена",
        })
        return
    }
    
    h.renderPage(c, "admin_edit_game.html", gin.H{
        "Title":      "Редактировать игру",
        "ActivePage": "admin",
        "Game":       game,
    })
}

func (h *GamePortalHandler) CreateNewGame(c *gin.Context) {
    var game models.Game
    
    game.Title = c.PostForm("title")
    game.Description = c.PostForm("description")
    game.Category = c.PostForm("category")
    
    // Обработка загрузки изображения
    imageFile, err := c.FormFile("game_image")
    if err == nil && imageFile != nil {
        ext := strings.ToLower(filepath.Ext(imageFile.Filename))
        imageID := time.Now().Unix()
        imageName := fmt.Sprintf("game_%d%s", imageID, ext)
        imagePath := filepath.Join("static", "images", "games", imageName)
        
        if err := os.MkdirAll(filepath.Join("static", "images", "games"), 0755); err != nil {
            c.HTML(http.StatusInternalServerError, "error_page.html", gin.H{
                "error": "Не удалось создать папку для изображений",
            })
            return
        }
        
        if err := c.SaveUploadedFile(imageFile, imagePath); err != nil {
            c.HTML(http.StatusInternalServerError, "error_page.html", gin.H{
                "error": "Не удалось сохранить изображение",
            })
            return
        }
        
        game.ImageURL = "/static/images/games/" + imageName
        game.Thumbnail = game.ImageURL
    }
    
    // Обработка загрузки ZIP файла
    zipFile, err := c.FormFile("game_zip")
    if err == nil && zipFile != nil {
        if !strings.HasSuffix(zipFile.Filename, ".zip") {
            c.HTML(http.StatusBadRequest, "error_page.html", gin.H{
                "error": "Файл должен быть в формате ZIP",
            })
            return
        }
        
        gameID := time.Now().Unix()
        gameFolder := fmt.Sprintf("game_%d", gameID)
        gamePath := filepath.Join("static", "games", gameFolder)
        
        if err := os.MkdirAll(gamePath, 0755); err != nil {
            c.HTML(http.StatusInternalServerError, "error_page.html", gin.H{
                "error": "Не удалось создать папку для игры",
            })
            return
        }
        
        zipPath := filepath.Join(gamePath, zipFile.Filename)
        if err := c.SaveUploadedFile(zipFile, zipPath); err != nil {
            c.HTML(http.StatusInternalServerError, "error_page.html", gin.H{
                "error": "Не удалось сохранить ZIP файл",
            })
            return
        }
        
        if err := unzip(zipPath, gamePath); err != nil {
            c.HTML(http.StatusInternalServerError, "error_page.html", gin.H{
                "error": "Не удалось распаковать архив: " + err.Error(),
            })
            return
        }
        
        os.Remove(zipPath)
        
        // Переименовываем файлы в Build для стандартных имен
        buildPath := filepath.Join(gamePath, "Build")
        if _, err := os.Stat(buildPath); err == nil {
            files, _ := os.ReadDir(buildPath)
            for _, file := range files {
                oldPath := filepath.Join(buildPath, file.Name())
                newName := strings.ReplaceAll(file.Name(), "Default", "WebGL")
                newName = strings.ReplaceAll(newName, "Minimal", "WebGL")
                if newName != file.Name() {
                    newPath := filepath.Join(buildPath, newName)
                    if err := os.Rename(oldPath, newPath); err == nil {
                        log.Printf("Renamed: %s -> %s", file.Name(), newName)
                    }
                }
            }
        }
        
        // Создаем папку StreamingAssets если её нет
        streamingAssetsPath := filepath.Join(gamePath, "StreamingAssets")
        if _, err := os.Stat(streamingAssetsPath); os.IsNotExist(err) {
            os.MkdirAll(streamingAssetsPath, 0755)
        }
        
        // Создаем index.html из универсального шаблона
        templatePath := filepath.Join("static", "games", "template.html")
        templateContent, err := os.ReadFile(templatePath)
        if err != nil {
            c.HTML(http.StatusInternalServerError, "error_page.html", gin.H{
                "error": "Не удалось загрузить шаблон игры",
            })
            return
        }
        
        // Заменяем плейсхолдеры
        content := string(templateContent)
        content = strings.ReplaceAll(content, "GAME_TITLE", game.Title)
        content = strings.ReplaceAll(content, "GAME_ID", "0") // временный ID
        
        indexPath := filepath.Join(gamePath, "index.html")
        if err := os.WriteFile(indexPath, []byte(content), 0644); err != nil {
            c.HTML(http.StatusInternalServerError, "error_page.html", gin.H{
                "error": "Не удалось сохранить файл игры",
            })
            return
        }
        
        game.FilePath = filepath.ToSlash(filepath.Join("games", gameFolder, "index.html"))
        game.ZipFile = zipFile.Filename
        
        // Сохраняем в БД
        err = h.repo.CreateGame(&game)
        if err != nil {
            c.HTML(http.StatusInternalServerError, "error_page.html", gin.H{
                "error": err.Error(),
            })
            return
        }
        
        // Обновляем index.html с правильным ID
        contentBytes, err := os.ReadFile(indexPath)
        if err == nil {
            newContent := strings.ReplaceAll(string(contentBytes), "GAME_ID", fmt.Sprintf("%d", game.ID))
            newContent = strings.ReplaceAll(newContent, "var gameId = 0;", fmt.Sprintf("var gameId = %d;", game.ID))
            newContent = strings.ReplaceAll(newContent, "var gameId = 0", fmt.Sprintf("var gameId = %d", game.ID))
            newContent = strings.ReplaceAll(newContent, "/api/game/0/", fmt.Sprintf("/api/game/%d/", game.ID))
            os.WriteFile(indexPath, []byte(newContent), 0644)
        }
        
        c.Redirect(http.StatusFound, "/admin")
        return
    }
    
    game.Width = 800
    game.Height = 600
    game.Plays = 0
    game.Rating = 0
    
    if game.Title == "" || game.FilePath == "" {
        c.HTML(http.StatusBadRequest, "error_page.html", gin.H{
            "error": "Название и файл игры обязательны",
        })
        return
    }
    
    err = h.repo.CreateGame(&game)
    if err != nil {
        c.HTML(http.StatusInternalServerError, "error_page.html", gin.H{
            "error": err.Error(),
        })
        return
    }
    
    c.Redirect(http.StatusFound, "/admin")
}

func (h *GamePortalHandler) UpdateExistingGame(c *gin.Context) {
    id, err := strconv.Atoi(c.Param("id"))
    if err != nil {
        c.HTML(http.StatusBadRequest, "error_page.html", gin.H{
            "error": "Неверный ID игры",
        })
        return
    }
    
    game, err := h.repo.GetGameByID(id)
    if err != nil {
        c.HTML(http.StatusNotFound, "error_page.html", gin.H{
            "error": "Игра не найдена",
        })
        return
    }
    
    game.Title = c.PostForm("title")
    game.Description = c.PostForm("description")
    game.Category = c.PostForm("category")
    game.FilePath = c.PostForm("file_path")
    game.ImageURL = c.PostForm("image_url")
    game.Thumbnail = c.PostForm("thumbnail")
    
    width, _ := strconv.Atoi(c.PostForm("width"))
    if width > 0 {
        game.Width = width
    }
    
    height, _ := strconv.Atoi(c.PostForm("height"))
    if height > 0 {
        game.Height = height
    }
    
    rating, _ := strconv.ParseFloat(c.PostForm("rating"), 64)
    if rating >= 0 && rating <= 5 {
        game.Rating = rating
    }
    
    err = h.repo.UpdateGame(game)
    if err != nil {
        c.HTML(http.StatusInternalServerError, "error_page.html", gin.H{
            "error": err.Error(),
        })
        return
    }
    
    c.Redirect(http.StatusFound, "/admin")
}

func (h *GamePortalHandler) DeleteExistingGame(c *gin.Context) {
    id, err := strconv.Atoi(c.Param("id"))
    if err != nil {
        c.HTML(http.StatusBadRequest, "error_page.html", gin.H{
            "error": "Неверный ID игры",
        })
        return
    }
    
    game, err := h.repo.GetGameByID(id)
    if err != nil {
        c.HTML(http.StatusNotFound, "error_page.html", gin.H{
            "error": "Игра не найдена",
        })
        return
    }
    
    // Удаляем папку с игрой
    if game.FilePath != "" {
        parts := strings.Split(game.FilePath, "/")
        if len(parts) >= 2 {
            gameFolderPath := filepath.Join("static", parts[0], parts[1])
            if err := os.RemoveAll(gameFolderPath); err != nil {
                fmt.Printf("Warning: Failed to delete game folder %s: %v\n", gameFolderPath, err)
            }
        }
    }
    
    // Удаляем изображение
    if game.ImageURL != "" {
        imagePath := strings.TrimPrefix(game.ImageURL, "/")
        imagePath = filepath.FromSlash(imagePath)
        os.Remove(imagePath)
    }
    
    err = h.repo.DeleteGame(id)
    if err != nil {
        c.HTML(http.StatusInternalServerError, "error_page.html", gin.H{
            "error": err.Error(),
        })
        return
    }
    
    c.Redirect(http.StatusFound, "/admin")
}

func (h *GamePortalHandler) Show404(c *gin.Context) {
    h.renderPage(c, "404.html", gin.H{
        "Title":      "Страница не найдена",
        "ActivePage": "404",
    })
}

func (h *GamePortalHandler) GenerateSitemap(c *gin.Context) {
    games, _, err := h.repo.ListGames(models.GameFilter{Page: 1, PageSize: 1000})
    if err != nil {
        c.String(http.StatusInternalServerError, "Error generating sitemap")
        return
    }
    
    c.Header("Content-Type", "application/xml")
    
    xml := `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`
    
    xml += `
    <url>
        <loc>https://igroplay.ru/</loc>
        <changefreq>daily</changefreq>
        <priority>1.0</priority>
    </url>`
    
    for _, game := range games {
        xml += fmt.Sprintf(`
    <url>
        <loc>https://igroplay.ru/game/%d</loc>
        <lastmod>%s</lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.8</priority>
    </url>`, game.ID, game.UpdatedAt.Format("2006-01-02"))
    }
    
    xml += `
</urlset>`
    
    c.String(http.StatusOK, xml)
}

// ============================================
// API HANDLERS
// ============================================

func (h *GamePortalHandler) TrackGamePlay(c *gin.Context) {
    id, err := strconv.Atoi(c.Param("id"))
    if err != nil {
        c.AbortWithStatus(http.StatusNotFound)
        return
    }
    
    referer := c.Request.Header.Get("Referer")
    if referer == "" || !strings.Contains(referer, "/game/") {
        c.AbortWithStatus(http.StatusNotFound)
        return
    }
    
    game, err := h.repo.GetGameByID(id)
    if err != nil {
        c.AbortWithStatus(http.StatusNotFound)
        return
    }
    
    if c.Query("track") == "1" {
        h.repo.IncrementGamePlays(id)
        c.JSON(http.StatusOK, gin.H{"success": true})
        return
    }
    
    filePath := c.Query("file")
    if filePath == "" {
        filePath = "index.html"
    }
    
    gameDir := filepath.Join("static", filepath.Dir(game.FilePath))
    fullPath := filepath.Join(gameDir, filePath)
    
    if _, err := os.Stat(fullPath); os.IsNotExist(err) {
        c.AbortWithStatus(http.StatusNotFound)
        return
    }
    
    contentType := "text/html"
    
    switch {
    case strings.HasSuffix(filePath, ".js"):
        contentType = "application/javascript"
    case strings.HasSuffix(filePath, ".wasm"):
        contentType = "application/wasm"
    case strings.HasSuffix(filePath, ".data"), strings.HasSuffix(filePath, ".unityweb"):
        contentType = "application/octet-stream"
    case strings.HasSuffix(filePath, ".css"):
        contentType = "text/css"
    case strings.HasSuffix(filePath, ".png"):
        contentType = "image/png"
    case strings.HasSuffix(filePath, ".jpg"), strings.HasSuffix(filePath, ".jpeg"):
        contentType = "image/jpeg"
    }
    
    c.Header("Content-Type", contentType)
    c.Header("Cache-Control", "no-cache")
    c.File(fullPath)
}

func (h *GamePortalHandler) GetCategoriesList(c *gin.Context) {
    games, _, err := h.repo.ListGames(models.GameFilter{Page: 1, PageSize: 1000})
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }
    
    categories := make(map[string]int)
    for _, game := range games {
        categories[game.Category]++
    }
    
    c.JSON(http.StatusOK, categories)
}

func (h *GamePortalHandler) GetGamesAPI(c *gin.Context) {
    page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
    category := c.Query("category")
    search := c.Query("search")
    sortBy := c.DefaultQuery("sort", "newest")
    
    if page < 1 {
        page = 1
    }
    
    filter := models.GameFilter{
        Category: category,
        Search:   search,
        SortBy:   sortBy,
        Page:     page,
        PageSize: 12,
    }
    
    games, _, err := h.repo.ListGames(filter)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }
    
    c.JSON(http.StatusOK, games)
}

func (h *GamePortalHandler) GetRandomGames(c *gin.Context) {
    limit := 6
    if l, err := strconv.Atoi(c.DefaultQuery("limit", "6")); err == nil && l > 0 && l <= 20 {
        limit = l
    }
    
    games, _, err := h.repo.ListGames(models.GameFilter{Page: 1, PageSize: 100})
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }
    
    rand.Shuffle(len(games), func(i, j int) {
        games[i], games[j] = games[j], games[i]
    })
    
    if len(games) > limit {
        games = games[:limit]
    }
    
    c.JSON(http.StatusOK, games)
}

func (h *GamePortalHandler) GetCategoriesWithCounts(c *gin.Context) {
    games, _, err := h.repo.ListGames(models.GameFilter{Page: 1, PageSize: 1000})
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }
    
    categoryMap := make(map[string]int)
    for _, game := range games {
        categoryMap[game.Category]++
    }
    
    categories := []map[string]interface{}{}
    for name, count := range categoryMap {
        categories = append(categories, map[string]interface{}{
            "Name":        name,
            "Count":       count,
            "DisplayName": getCategoryDisplayName(name),
            "Icon":        getCategoryIcon(name),
        })
    }
    
    c.JSON(http.StatusOK, categories)
}

// ============================================
// ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// ============================================

func unzip(zipPath, destPath string) error {
    archive, err := zip.OpenReader(zipPath)
    if err != nil {
        return err
    }
    defer archive.Close()
    
    for _, f := range archive.File {
        filePath := filepath.Join(destPath, f.Name)
        
        if !strings.HasPrefix(filePath, filepath.Clean(destPath)+string(os.PathSeparator)) {
            return fmt.Errorf("invalid file path: %s", f.Name)
        }
        
        if f.FileInfo().IsDir() {
            os.MkdirAll(filePath, 0755)
            continue
        }
        
        if err := os.MkdirAll(filepath.Dir(filePath), 0755); err != nil {
            return err
        }
        
        destFile, err := os.OpenFile(filePath, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, f.Mode())
        if err != nil {
            return err
        }
        
        srcFile, err := f.Open()
        if err != nil {
            destFile.Close()
            return err
        }
        
        _, err = io.Copy(destFile, srcFile)
        destFile.Close()
        srcFile.Close()
        
        if err != nil {
            return err
        }
    }
    
    return nil
}

func findIndexHTML(path string) string {
    var indexFile string
    filepath.Walk(path, func(p string, info os.FileInfo, err error) error {
        if err != nil {
            return nil
        }
        if !info.IsDir() && strings.EqualFold(info.Name(), "index.html") {
            relPath, _ := filepath.Rel(path, p)
            indexFile = filepath.ToSlash(relPath)
            return filepath.SkipDir
        }
        return nil
    })
    return indexFile
}

func getCategoryDisplayName(category string) string {
    names := map[string]string{
        "arcade":      "Аркады",
        "puzzle":      "Головоломки",
        "strategy":    "Стратегии",
        "rpg":         "RPG",
        "multiplayer": "Мультиплеер",
        "board":       "Настольные",
        "action":      "Экшн",
        "racing":      "Гонки",
        "card":        "Карточные",
        "horror":      "Хоррор",
    }
    if name, ok := names[category]; ok {
        return name
    }
    return category
}

func getCategoryIcon(category string) string {
    icons := map[string]string{
        "arcade":      "fas fa-bolt",
        "puzzle":      "fas fa-puzzle-piece",
        "strategy":    "fas fa-chess-queen",
        "rpg":         "fas fa-hat-wizard",
        "multiplayer": "fas fa-users",
        "board":       "fas fa-chess-board",
        "action":      "fas fa-crosshairs",
        "racing":      "fas fa-car-side",
        "card":        "fas fa-clone",
        "horror":      "fas fa-ghost",
    }
    if icon, ok := icons[category]; ok {
        return icon
    }
    return "fas fa-gamepad"
}

func createProperGameIndexHTML(gamePath, gameFolder string, gameID int64, gameTitle string) error {
    templatePath := filepath.Join("static", "games", "template.html")
    
    templateContent, err := os.ReadFile(templatePath)
    if err != nil {
        return fmt.Errorf("cannot read template: %v", err)
    }
    
    content := string(templateContent)
    content = strings.ReplaceAll(content, "GAME_ID", fmt.Sprintf("%d", gameID))
    content = strings.ReplaceAll(content, "GAME_TITLE", gameTitle)
    
    indexPath := filepath.Join(gamePath, "index.html")
    return os.WriteFile(indexPath, []byte(content), 0644)
}