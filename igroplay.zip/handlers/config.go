package handlers

import (
    "browser-games-portal/models"
    "net/http"
    
    "github.com/gin-contrib/sessions"
    "github.com/gin-gonic/gin"
)

type ConfigHandler struct {
    repo          *models.ConfigRepository
    portalHandler *GamePortalHandler
}

func NewConfigHandler(repo *models.ConfigRepository, portalHandler *GamePortalHandler) *ConfigHandler {
    return &ConfigHandler{repo: repo, portalHandler: portalHandler}
}

// ShowConfigPage отображает страницу конфигурации
func (h *ConfigHandler) ShowConfigPage(c *gin.Context) {
    session := sessions.Default(c)
    role := session.Get("role")
    if role != "admin" {
        c.HTML(http.StatusForbidden, "error_page.html", gin.H{
            "error": "Доступ запрещен",
        })
        return
    }
    
    config, err := h.repo.GetConfig()
    if err != nil {
        c.HTML(http.StatusInternalServerError, "error_page.html", gin.H{
            "error": err.Error(),
        })
        return
    }
    
    h.portalHandler.renderPage(c, "admin_config.html", gin.H{
        "Title":      "Конфигурация сайта",
        "ActivePage": "admin",
        "Config":     config,
        "success":    c.Query("success"),
    })
}

// UpdateConfig обновляет конфигурацию сайта
func (h *ConfigHandler) UpdateConfig(c *gin.Context) {
    session := sessions.Default(c)
    role := session.Get("role")
    if role != "admin" {
        c.JSON(http.StatusForbidden, gin.H{"error": "Доступ запрещен"})
        return
    }
    
    config, err := h.repo.GetConfig()
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }
    
    // Обновляем все поля
    config.SiteName = c.PostForm("site_name")
    config.LogoHTML = c.PostForm("logo_html")
    config.FooterLogoHTML = c.PostForm("footer_logo_html")  // ← ДОБАВЛЯЕМ
    config.FooterText = c.PostForm("footer_text")
    config.FooterCopyright = c.PostForm("footer_copyright")
    config.MetaTitle = c.PostForm("meta_title")
    config.MetaDescription = c.PostForm("meta_description")
    config.MetaKeywords = c.PostForm("meta_keywords")
    
    err = h.repo.UpdateConfig(config)
    if err != nil {
        c.HTML(http.StatusInternalServerError, "error_page.html", gin.H{
            "error": err.Error(),
        })
        return
    }
    
    c.Redirect(http.StatusFound, "/admin/config?success=1")
}