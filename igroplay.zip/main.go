package main

import (
    "browser-games-portal/config"
    "browser-games-portal/handlers"
    "browser-games-portal/models"
    "database/sql"
    "fmt"
    "html/template"
    "log"
    "net/http"
    "os"
    "path/filepath"
    "runtime"
    "strings"
    "time"
    
    "github.com/gin-contrib/sessions"
    "github.com/gin-contrib/sessions/cookie"
    "github.com/gin-gonic/gin"
    _ "github.com/lib/pq"
)

func main() {
    log.Printf("🖥️  Running on: %s/%s", runtime.GOOS, runtime.GOARCH)
    
    cfg := config.LoadAppConfig()
    
    if cfg.DBPassword == "" {
        log.Fatal("❌ Database password is not configured")
    }
    
    connStr := cfg.GetPostgresConnectionString()
    log.Println("🔌 Connecting to PostgreSQL...")
    
    db, err := sql.Open("postgres", connStr)
    if err != nil {
        log.Fatal("❌ Failed to connect to database:", err)
    }
    defer db.Close()
    
    err = db.Ping()
    if err != nil {
        log.Fatal("❌ Failed to ping database:", err)
    }
    log.Println("✅ Successfully connected to PostgreSQL")
    
    go func() {
        ticker := time.NewTicker(5 * time.Minute)
        defer ticker.Stop()
        for range ticker.C {
            if err := db.Ping(); err != nil {
                log.Printf("⚠️ Database ping failed: %v", err)
            }
        }
    }()
    
    repo := models.NewGameRepository(db)
    configRepo := models.NewConfigRepository(db)
    
    log.Println("📋 Creating tables if not exist...")
    err = repo.CreateGamesTable()
    if err != nil {
        log.Fatal("❌ Failed to create games table:", err)
    }
    
    err = repo.CreateUsersTable()
    if err != nil {
        log.Fatal("❌ Failed to create users table:", err)
    }
    
    err = configRepo.CreateConfigTable()
    if err != nil {
        log.Fatal("❌ Failed to create config table:", err)
    }
    log.Println("✅ Tables created/verified")
    
    if os.Getenv("GIN_MODE") == "release" {
        gin.SetMode(gin.ReleaseMode)
    }
    
    r := gin.Default()
    
    // CORS заголовки
    r.Use(func(c *gin.Context) {
        c.Header("Access-Control-Allow-Origin", "*")
        c.Header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        c.Header("Access-Control-Allow-Headers", "Content-Type")
        c.Header("Cross-Origin-Embedder-Policy", "require-corp")
        c.Header("Cross-Origin-Opener-Policy", "same-origin")
        c.Header("X-Frame-Options", "SAMEORIGIN")
        c.Header("X-Content-Type-Options", "nosniff")
        
        if c.Request.Method == "OPTIONS" {
            c.AbortWithStatus(204)
            return
        }
        c.Next()
    })
    
    // Настройка сессий
    store := cookie.NewStore([]byte(cfg.SessionSecret))
    store.Options(sessions.Options{
        MaxAge:   86400 * 30,
        HttpOnly: true,
        SameSite: http.SameSiteLaxMode,
        Path:     "/",
    })
    r.Use(sessions.Sessions("gamesession", store))
    
    // Инициализация обработчиков
    handler := handlers.NewGamePortalHandler(repo)
    gameAPI := handlers.NewGameAPI(repo)
    configHandler := handlers.NewConfigHandler(configRepo, handler)
    
    // ============================================
    // СТАТИЧЕСКИЕ ФАЙЛЫ
    // ============================================
    
    // Блокируем прямой доступ к папке games
    r.Use(func(c *gin.Context) {
        if strings.Contains(c.Request.URL.Path, "/static/games/") {
            c.AbortWithStatus(http.StatusNotFound)
            return
        }
        c.Next()
    })
    
    // Статические файлы
    r.Static("/static/css", "./static/css")
    r.Static("/static/js", "./static/js")
    r.Static("/static/images", "./static/images")
    
    // robots.txt
    r.GET("/robots.txt", func(c *gin.Context) {
        c.String(http.StatusOK, `User-agent: *
Allow: /
Disallow: /static/games/
Disallow: /admin/
Disallow: /api/
Disallow: /dashboard/
Disallow: /balance/

Sitemap: https://igroplay.ru/sitemap.xml`)
    })
    
    // Функции для шаблонов
    funcMap := template.FuncMap{
        "add": func(a, b int) int {
            return a + b
        },
        "sub": func(a, b int) int {
            return a - b
        },
        "first": func(n int, games []models.Game) []models.Game {
            if n > len(games) {
                return games
            }
            return games[:n]
        },
        "last": func(n int, games []models.Game) []models.Game {
            if n > len(games) {
                return games
            }
            return games[len(games)-n:]
        },
        "slice": func(games []models.Game, start, end int) []models.Game {
            if start < 0 {
                start = 0
            }
            if end > len(games) {
                end = len(games)
            }
            if start >= len(games) {
                return []models.Game{}
            }
            return games[start:end]
        },
    }
    
    templates, err := loadTemplates("templates", funcMap)
    if err != nil {
        log.Fatal("❌ Failed to load templates:", err)
    }
    r.SetHTMLTemplate(templates)
    
    // ============================================
    // ПУБЛИЧНЫЕ МАРШРУТЫ
    // ============================================
    
    r.GET("/", handler.ShowHomePage)
    r.GET("/game/:id", handler.ShowGameDetail)
    r.GET("/dashboard", handler.ShowDashboard)
    r.GET("/register", handler.ShowRegisterPage)
    r.POST("/register", handler.HandleUserRegistration)
    r.POST("/login", handler.HandleUserLogin)
    r.GET("/logout", handler.HandleUserLogout)
    r.GET("/balance", handler.ShowBalance)
    
    // ============================================
    // API МАРШРУТЫ (для игры)
    // ============================================
    
    r.GET("/api/game/:id/play", handler.TrackGamePlay)
    r.GET("/api/categories", handler.GetCategoriesList)
    r.GET("/api/categories/detailed", handler.GetCategoriesWithCounts)
    r.GET("/api/games", handler.GetGamesAPI)
    r.GET("/api/games/random", handler.GetRandomGames)
    
    // ============================================
    // GAME API МАРШРУТЫ (для взаимодействия игры с сайтом)
    // ============================================
    
    r.GET("/api/game/user/info", gameAPI.GetUserInfo)
    r.POST("/api/game/balance/add", gameAPI.AddBalance)
    r.POST("/api/game/balance/spend", gameAPI.SpendBalance)
    r.POST("/api/game/ad/rewarded", gameAPI.ShowRewardedAd)
    r.POST("/api/game/progress/save", gameAPI.SaveGameProgress)
    r.GET("/api/game/progress/load/:id", gameAPI.LoadGameProgress)
    r.GET("/api/game/leaderboard/:id", gameAPI.GetLeaderboard)
    r.POST("/api/game/score/submit", gameAPI.SubmitScore)
    
    // SEO
    r.GET("/sitemap.xml", handler.GenerateSitemap)
    
    // ============================================
    // АДМИН-ПАНЕЛЬ
    // ============================================
    
    admin := r.Group("/admin")
    admin.Use(handler.AuthRequiredMiddleware())
    admin.Use(handler.AdminRequiredMiddleware())
    {
        admin.GET("/", handler.ShowAdminPanel)
        admin.GET("/games/new", handler.ShowAddGameForm)
        admin.POST("/games", handler.CreateNewGame)
        admin.GET("/games/:id/edit", handler.ShowEditGameForm)
        admin.POST("/games/:id", handler.UpdateExistingGame)
        admin.POST("/games/:id/delete", handler.DeleteExistingGame)
        admin.GET("/config", configHandler.ShowConfigPage)
        admin.POST("/config", configHandler.UpdateConfig)
    }
    
    // Обработчик 404
    r.NoRoute(func(c *gin.Context) {
        handler.Show404(c)
    })
    
    serverURL := fmt.Sprintf("http://localhost:%s", cfg.ServerPort)
    log.Println("🚀 igroplay.ru server starting...")
    log.Printf("📍 Server URL: %s", serverURL)
    log.Println("📝 Admin login: admin / admin123")
    log.Println("⚠️  Press Ctrl+C to stop the server")
    
    r.Run(":" + cfg.ServerPort)
}

func loadTemplates(rootDir string, funcMap template.FuncMap) (*template.Template, error) {
    tmpl := template.New("").Funcs(funcMap)
    
    err := filepath.Walk(rootDir, func(path string, info os.FileInfo, err error) error {
        if err != nil {
            return err
        }
        if !info.IsDir() && filepath.Ext(path) == ".html" {
            log.Printf("📄 Loading template: %s", path)
            _, err := tmpl.ParseFiles(path)
            if err != nil {
                log.Printf("❌ Error loading %s: %v", path, err)
                return err
            }
        }
        return nil
    })
    
    if err != nil {
        return nil, err
    }
    
    return tmpl, nil
}