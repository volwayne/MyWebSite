/* ========================================
   FRONTEND SCRIPTS - Browser Games Portal
   ======================================== */

// Ждем полной загрузки DOM
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 igroplay.ru initialized');
    
    // Инициализация всех компонентов
    initAnimations();
    initSearchFilters();
    initGamePlayTracking();
    initCategoriesLoader();
});

/* ========================================
   ANIMATIONS
   ======================================== */
function initAnimations() {
    const filters = document.querySelector('.filters');
    if (filters) {
        filters.classList.add('animate-slide-down');
    }
    
    const adminSections = document.querySelectorAll('.admin-section');
    adminSections.forEach((section, index) => {
        section.style.animationDelay = `${index * 0.1}s`;
    });
    
    // Ripple эффект для кнопок
    const buttons = document.querySelectorAll('.btn, .btn-play, button');
    buttons.forEach(button => {
        button.addEventListener('click', createRippleEffect);
    });
}

function createRippleEffect(event) {
    const button = event.currentTarget;
    const ripple = document.createElement('span');
    const rect = button.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = event.clientX - rect.left - size / 2;
    const y = event.clientY - rect.top - size / 2;
    
    ripple.style.width = ripple.style.height = size + 'px';
    ripple.style.left = x + 'px';
    ripple.style.top = y + 'px';
    ripple.classList.add('ripple-effect');
    
    button.appendChild(ripple);
    
    setTimeout(() => {
        ripple.remove();
    }, 600);
}

/* ========================================
   SEARCH & FILTERS
   ======================================== */
function initSearchFilters() {
    const searchForm = document.querySelector('.search-form');
    if (!searchForm) return;
    
    const searchInput = searchForm.querySelector('input[name="search"]');
    const categorySelect = searchForm.querySelector('select[name="category"]');
    const sortSelect = searchForm.querySelector('select[name="sort"]');
    
    if (searchInput) {
        let searchTimeout;
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                if (this.value.length >= 3 || this.value.length === 0) {
                    searchForm.submit();
                }
            }, 500);
        });
    }
    
    if (categorySelect) {
        categorySelect.addEventListener('change', () => searchForm.submit());
    }
    
    if (sortSelect) {
        sortSelect.addEventListener('change', () => searchForm.submit());
    }
}

/* ========================================
   GAME CARDS
   ======================================== */

/* ========================================
   GAME PLAY TRACKING
   ======================================== */
function initGamePlayTracking() {
    const playButtons = document.querySelectorAll('.btn-play, .game-card .btn');
    
    playButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            let gameId = null;
            const href = this.getAttribute('href');
            
            if (href && href.includes('/game/')) {
                const match = href.match(/\/game\/(\d+)/);
                if (match) {
                    gameId = match[1];
                }
            }
            
            if (gameId) {
                trackGamePlay(gameId);
            }
        });
    });
}

async function trackGamePlay(gameId) {
    try {
        const response = await fetch(`/api/game/${gameId}/play`);
        const data = await response.json();
        console.log(`Game ${gameId} play tracked:`, data);
    } catch (error) {
        console.error('Error tracking game play:', error);
    }
}

/* ========================================
   CATEGORIES LOADER
   ======================================== */
async function initCategoriesLoader() {
    const categorySelect = document.querySelector('select[name="category"]');
    if (!categorySelect) return;
    
    try {
        const response = await fetch('/api/categories');
        const categories = await response.json();
        console.log('Available categories:', categories);
        
        const options = categorySelect.querySelectorAll('option');
        options.forEach(option => {
            const categoryValue = option.value;
            if (categoryValue && categories[categoryValue]) {
                option.textContent = `${categoryValue} (${categories[categoryValue]})`;
            }
        });
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

/* ========================================
   MOBILE MENU
   ======================================== */
function initMobileMenu() {
    const header = document.querySelector('header');
    if (!header) return;
    
    if (window.innerWidth <= 768) {
        const nav = header.querySelector('nav');
        const container = header.querySelector('.header-container');
        
        if (nav && !document.querySelector('.mobile-menu-btn')) {
            const menuBtn = document.createElement('button');
            menuBtn.className = 'mobile-menu-btn';
            menuBtn.innerHTML = '☰';
            menuBtn.setAttribute('aria-label', 'Меню');
            
            container.insertBefore(menuBtn, nav);
            
            menuBtn.addEventListener('click', () => {
                nav.classList.toggle('show');
                menuBtn.classList.toggle('active');
            });
        }
    }
    
    window.addEventListener('resize', () => {
        if (window.innerWidth > 768) {
            const nav = document.querySelector('nav');
            const menuBtn = document.querySelector('.mobile-menu-btn');
            if (nav) nav.classList.remove('show');
            if (menuBtn) menuBtn.classList.remove('active');
        }
    });
}