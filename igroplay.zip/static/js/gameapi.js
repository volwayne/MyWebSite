// GameAPI - клиентское API для взаимодействия игры с сайтом
(function() {
    if (window.GameAPI) return;
    
    var api = {};
    var baseUrl = window.location.origin + '/api/game';
    
    function request(url, method, data) {
        return fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
            },
            body: data ? JSON.stringify(data) : undefined,
            credentials: 'include'
        })
        .then(function(response) {
            var contentType = response.headers.get('content-type');
            if (contentType && contentType.includes('application/json')) {
                return response.json();
            }
            return response.text().then(function(text) {
                throw new Error('Invalid response: ' + text.substring(0, 100));
            });
        })
        .catch(function(error) {
            console.error('GameAPI error:', error);
            return { success: false, error: error.message };
        });
    }
    
    api.getUserInfo = function() {
        return request(baseUrl + '/user/info', 'GET');
    };
    
    api.addBalance = function(amount, reason) {
        return request(baseUrl + '/balance/add', 'POST', {
            amount: amount,
            reason: reason
        });
    };
    
    api.spendBalance = function(amount, item, itemId) {
        return request(baseUrl + '/balance/spend', 'POST', {
            amount: amount,
            item: item,
            item_id: itemId
        });
    };
    
    api.showRewardedAd = function() {
        return request(baseUrl + '/ad/rewarded', 'POST', {});
    };
    
    api.saveProgress = function(gameId, progress) {
        return request(baseUrl + '/progress/save', 'POST', {
            game_id: gameId,
            progress: progress
        });
    };
    
    api.loadProgress = function(gameId) {
        return request(baseUrl + '/progress/load/' + gameId, 'GET');
    };
    
    api.getLeaderboard = function(gameId) {
        return request(baseUrl + '/leaderboard/' + gameId, 'GET');
    };
    
    api.submitScore = function(gameId, score) {
        return request(baseUrl + '/score/submit', 'POST', {
            game_id: gameId,
            score: score
        });
    };
    
    // Проверка баланса
    api.checkBalance = function() {
        return api.getUserInfo().then(function(data) {
            if (data.success) {
                return { success: true, balance: data.user.balance };
            }
            return { success: false, error: data.error };
        });
    };
    
    // Попытка потратить с проверкой
    api.trySpendBalance = function(amount, item, itemId) {
        return api.spendBalance(amount, item, itemId);
    };
    
    window.GameAPI = api;
    console.log('GameAPI loaded successfully');
	
	window.sendToUnity = function(gameObject, method, data) {
    if (window.unityInstance) {
        window.unityInstance.SendMessage(gameObject, method, JSON.stringify(data));
    }
};
})();