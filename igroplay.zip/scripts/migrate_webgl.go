package main

import (
    "browser-games-portal/config"
    "database/sql"
    "fmt"
    "log"
    
    _ "github.com/lib/pq"
)

func main() {
    fmt.Println("========================================")
    fmt.Println("  Migrating database for WebGL games")
    fmt.Println("========================================")
    fmt.Println()
    
    cfg := config.LoadAppConfig()
    
    if cfg.DBPassword == "" {
        log.Fatal("❌ Database password is not configured")
    }
    
    connStr := cfg.GetPostgresConnectionString()
    db, err := sql.Open("postgres", connStr)
    if err != nil {
        log.Fatal("❌ Failed to connect:", err)
    }
    defer db.Close()
    
    err = db.Ping()
    if err != nil {
        log.Fatal("❌ Failed to ping database:", err)
    }
    fmt.Println("✅ Connected to PostgreSQL")
    fmt.Println()
    
    // Проверяем существующие колонки
    fmt.Println("📋 Checking existing columns...")
    
    // Добавляем колонку file_path
    fmt.Println("   Adding file_path column...")
    _, err = db.Exec("ALTER TABLE games ADD COLUMN IF NOT EXISTS file_path TEXT")
    if err != nil {
        fmt.Printf("   ❌ Error adding file_path: %v\n", err)
    } else {
        fmt.Println("   ✅ file_path column added")
    }
    
    // Добавляем колонку thumbnail
    fmt.Println("   Adding thumbnail column...")
    _, err = db.Exec("ALTER TABLE games ADD COLUMN IF NOT EXISTS thumbnail TEXT")
    if err != nil {
        fmt.Printf("   ❌ Error adding thumbnail: %v\n", err)
    } else {
        fmt.Println("   ✅ thumbnail column added")
    }
    
    // Добавляем колонку width
    fmt.Println("   Adding width column...")
    _, err = db.Exec("ALTER TABLE games ADD COLUMN IF NOT EXISTS width INTEGER DEFAULT 800")
    if err != nil {
        fmt.Printf("   ❌ Error adding width: %v\n", err)
    } else {
        fmt.Println("   ✅ width column added")
    }
    
    // Добавляем колонку height
    fmt.Println("   Adding height column...")
    _, err = db.Exec("ALTER TABLE games ADD COLUMN IF NOT EXISTS height INTEGER DEFAULT 600")
    if err != nil {
        fmt.Printf("   ❌ Error adding height: %v\n", err)
    } else {
        fmt.Println("   ✅ height column added")
    }
    
    fmt.Println()
    fmt.Println("📝 Updating existing games...")
    
    // Обновляем существующие записи: копируем url в file_path если нужно
    _, err = db.Exec("UPDATE games SET file_path = url, width = 800, height = 600 WHERE file_path IS NULL AND url IS NOT NULL")
    if err != nil {
        fmt.Printf("   ⚠️  Warning while updating: %v\n", err)
    } else {
        fmt.Println("   ✅ Existing games updated")
    }
    
    fmt.Println()
    fmt.Println("✅ Migration completed successfully!")
    fmt.Println()
    fmt.Println("New columns added:")
    fmt.Println("   - file_path (TEXT) - путь к WebGL игре")
    fmt.Println("   - thumbnail (TEXT) - миниатюра игры")
    fmt.Println("   - width (INTEGER) - ширина игрового окна")
    fmt.Println("   - height (INTEGER) - высота игрового окна")
}