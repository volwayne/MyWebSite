@echo off
chcp 65001 > nul
echo ========================================
echo   WebGL Database Migration
echo ========================================
echo.
echo This will add new columns for WebGL games:
echo   - file_path (path to WebGL game)
echo   - thumbnail (game thumbnail)
echo   - width (game window width)
echo   - height (game window height)
echo.
echo Make sure PostgreSQL is running!
echo.
pause

echo.
echo Running migration...
go run scripts/migrate_webgl.go

echo.
echo Migration completed!
echo.
pause