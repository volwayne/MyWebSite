@echo off
chcp 65001 > nul
color 0A
echo ========================================
echo   PlayerRe.Ru Database Tools
echo ========================================
echo.
echo 1. Seed database (add demo games + admin)
echo 2. Clean database (remove all games)
echo 3. Exit
echo.
set /p choice="Choose option (1-3): "

if "%choice%"=="1" (
    cls
    go run scripts/seed.go
    echo.
    pause
) else if "%choice%"=="2" (
    cls
    go run scripts/clean.go
    echo.
    pause
) else (
    exit
)