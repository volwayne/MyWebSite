package main

import (
    "browser-games-portal/config"
    "database/sql"
    "fmt"
    "log"
    
    _ "github.com/lib/pq"
)

func main() {
    fmt.Println("========================================")
    fmt.Println("  Adding zip_file column to games table")
    fmt.Println("========================================")
    fmt.Println()
    
    cfg := config.LoadAppConfig()
    
    if cfg.DBPassword == "" {
        log.Fatal("❌ Database password is not configured")
    }
    
    connStr := cfg.GetPostgresConnectionString()
    db, err := sql.Open("postgres", connStr)
    if err != nil {
        log.Fatal("❌ Failed to connect:", err)
    }
    defer db.Close()
    
    err = db.Ping()
    if err != nil {
        log.Fatal("❌ Failed to ping database:", err)
    }
    fmt.Println("✅ Connected to PostgreSQL")
    fmt.Println()
    
    // Добавляем колонку zip_file
    fmt.Println("📋 Adding zip_file column...")
    _, err = db.Exec("ALTER TABLE games ADD COLUMN IF NOT EXISTS zip_file TEXT DEFAULT ''")
    if err != nil {
        fmt.Printf("❌ Error: %v\n", err)
    } else {
        fmt.Println("✅ zip_file column added")
    }
    
    fmt.Println()
    fmt.Println("✅ Migration completed successfully!")
}