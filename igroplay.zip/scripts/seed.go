package main

import (
    "browser-games-portal/config"
    "browser-games-portal/models"
    "database/sql"
    "fmt"
    "log"
    
    _ "github.com/lib/pq"
    "golang.org/x/crypto/bcrypt"
)

func main() {
    fmt.Println("========================================")
    fmt.Println("  PlayerRe.Ru Database Seeder")
    fmt.Println("========================================")
    fmt.Println()
    
    // Загрузка конфигурации
    cfg := config.LoadAppConfig()
    
    if cfg.DBPassword == "" {
        log.Fatal("❌ Database password is not configured")
    }
    
    // Подключение к PostgreSQL
    connStr := cfg.GetPostgresConnectionString()
    db, err := sql.Open("postgres", connStr)
    if err != nil {
        log.Fatal("❌ Failed to connect:", err)
    }
    defer db.Close()
    
    // Проверка подключения
    err = db.Ping()
    if err != nil {
        log.Fatal("❌ Failed to ping database:", err)
    }
    fmt.Println("✅ Connected to PostgreSQL")
    fmt.Println()
    
    // Инициализация репозитория
    repo := models.NewGameRepository(db)
    
    // Создание таблиц если не существуют
    fmt.Println("📋 Creating tables if not exist...")
    err = repo.CreateGamesTable()
    if err != nil {
        log.Fatal("❌ Failed to create games table:", err)
    }
    
    err = repo.CreateUsersTable()
    if err != nil {
        log.Fatal("❌ Failed to create users table:", err)
    }
    fmt.Println("✅ Tables created/verified")
    fmt.Println()
    
    // Проверяем наличие администратора
    fmt.Println("👤 Checking admin user...")
    _, err = repo.GetUserByUsername("admin")
    if err != nil {
        fmt.Println("   Creating admin user...")
        hashedPassword, err := bcrypt.GenerateFromPassword([]byte("admin123"), bcrypt.DefaultCost)
        if err != nil {
            log.Fatal("❌ Failed to hash password:", err)
        }
        
        admin := &models.User{
            Username: "admin",
            Password: string(hashedPassword),
            Email:    "admin@playere.ru",
            Role:     "admin",
        }
        
        err = repo.CreateUser(admin)
        if err != nil {
            log.Fatal("❌ Failed to create admin:", err)
        }
        fmt.Println("   ✅ Admin user created: admin / admin123")
    } else {
        fmt.Println("   ✅ Admin user already exists")
    }
    fmt.Println()
    
    // Проверяем, есть ли уже игры
    games, _, err := repo.ListGames(models.GameFilter{Page: 1, PageSize: 1})
    if err != nil {
        log.Fatal("❌ Failed to check existing games:", err)
    }
    
    if len(games) > 0 {
        fmt.Println("📊 Games already exist in database. Skipping seed...")
        fmt.Println()
        fmt.Println("========================================")
        fmt.Println("  Seeding completed!")
        fmt.Println("========================================")
        return
    }
    
    // Демо-игры
    fmt.Println("🎮 Adding demo games...")
    fmt.Println()
    
    demoGames := []models.Game{
        {
            Title:       "Kingdom Clash",
            Description: "Эпическая стратегия, где вы строите свою империю и сражаетесь с другими игроками.",
            Category:    "strategy",
            URL:         "https://kingdomclash.com",
            ImageURL:    "https://picsum.photos/id/104/400/225",
            Plays:       1250,
            Rating:      4.9,
        },
        {
            Title:       "Shadow Arena",
            Description: "Динамичный экшн с элементами RPG. Выбирайте героя, прокачивайте способности.",
            Category:    "action",
            URL:         "https://shadowarena.com",
            ImageURL:    "https://picsum.photos/id/96/400/225",
            Plays:       2100,
            Rating:      4.8,
        },
        {
            Title:       "Neon Drift",
            Description: "Киберпанк-аркада на высоких скоростях. Участвуйте в захватывающих гонках.",
            Category:    "racing",
            URL:         "https://neondrift.com",
            ImageURL:    "https://picsum.photos/id/107/400/225",
            Plays:       856,
            Rating:      4.7,
        },
        {
            Title:       "Mystic Realms",
            Description: "Погрузитесь в мир магии и приключений. Исследуйте древние земли.",
            Category:    "rpg",
            URL:         "https://mysticrealms.com",
            ImageURL:    "https://picsum.photos/id/26/400/225",
            Plays:       980,
            Rating:      4.6,
        },
        {
            Title:       "Chess Royale",
            Description: "Современная интерпретация классических шахмат. Сражайтесь с игроками со всего мира.",
            Category:    "board",
            URL:         "https://chessroyale.com",
            ImageURL:    "https://picsum.photos/id/169/400/225",
            Plays:       450,
            Rating:      4.5,
        },
        {
            Title:       "Rogue Deck",
            Description: "Карточная игра с элементами roguelike. Собирайте мощные колоды, побеждайте врагов.",
            Category:    "card",
            URL:         "https://roguedeck.com",
            ImageURL:    "https://picsum.photos/id/106/400/225",
            Plays:       630,
            Rating:      4.7,
        },
        {
            Title:       "Zombie Outbreak",
            Description: "Игра на выживание в мире, охваченном зомби-апокалипсисом.",
            Category:    "horror",
            URL:         "https://zombieoutbreak.com",
            ImageURL:    "https://picsum.photos/id/42/400/225",
            Plays:       1540,
            Rating:      4.8,
        },
        {
            Title:       "2048 Classic",
            Description: "Популярная головоломка, где нужно собирать плитки с числами до 2048.",
            Category:    "puzzle",
            URL:         "https://play2048.co/",
            ImageURL:    "https://picsum.photos/id/104/400/225",
            Plays:       2100,
            Rating:      4.8,
        },
        {
            Title:       "Flappy Bird",
            Description: "Классическая аркада, где нужно управлять птичкой, пролетая между трубами.",
            Category:    "arcade",
            URL:         "https://flappybird.io/",
            ImageURL:    "https://picsum.photos/id/96/400/225",
            Plays:       3200,
            Rating:      4.5,
        },
        {
            Title:       "Slither.io",
            Description: "Многопользовательская игра, где нужно расти, поедая разноцветные шары.",
            Category:    "multiplayer",
            URL:         "https://slither.io/",
            ImageURL:    "https://picsum.photos/id/107/400/225",
            Plays:       4500,
            Rating:      4.7,
        },
    }
    
    for _, game := range demoGames {
        if err := repo.CreateGame(&game); err != nil {
            log.Printf("   ❌ Failed to add game %s: %v", game.Title, err)
        } else {
            fmt.Printf("   ✓ Added: %s\n", game.Title)
        }
    }
    
    fmt.Println()
    fmt.Println("✅ Demo data added successfully!")
    fmt.Printf("📊 Total games: %d\n", len(demoGames))
    fmt.Println()
    fmt.Println("========================================")
    fmt.Println("  Seeding completed!")
    fmt.Println("========================================")
}