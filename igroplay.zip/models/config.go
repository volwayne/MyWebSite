package models

import (
    "database/sql"
    "time"
)

// SiteConfig - модель конфигурации сайта
type SiteConfig struct {
    ID              int       `json:"id"`
    SiteName        string    `json:"site_name"`
    LogoHTML        string    `json:"logo_html"`          // HTML код логотипа в шапке
    FooterLogoHTML  string    `json:"footer_logo_html"`   // HTML код логотипа в футере
    FooterText      string    `json:"footer_text"`
    FooterCopyright string    `json:"footer_copyright"`
    MetaTitle       string    `json:"meta_title"`
    MetaDescription string    `json:"meta_description"`
    MetaKeywords    string    `json:"meta_keywords"`
    UpdatedAt       time.Time `json:"updated_at"`
}

// ConfigRepository - репозиторий для работы с конфигурацией
type ConfigRepository struct {
    DB *sql.DB
}

func NewConfigRepository(db *sql.DB) *ConfigRepository {
    return &ConfigRepository{DB: db}
}

// CreateConfigTable создает таблицу конфигурации
func (r *ConfigRepository) CreateConfigTable() error {
    query := `
    CREATE TABLE IF NOT EXISTS site_config (
        id SERIAL PRIMARY KEY,
        site_name VARCHAR(255) DEFAULT 'igroplay.ru',
        logo_html TEXT DEFAULT '<div class="header-logo-icon"><i class="fas fa-gamepad"></i></div><div class="header-logo-text">igro<span>play</span></div>',
        footer_logo_html TEXT DEFAULT '<h3>igro<span>play</span></h3>',
        footer_text TEXT DEFAULT 'Лучший каталог браузерных игр. Играй бесплатно онлайн!',
        footer_copyright VARCHAR(255) DEFAULT '© 2024 igroplay.ru. Все права защищены.',
        meta_title VARCHAR(255) DEFAULT 'Игры онлайн',
        meta_description TEXT DEFAULT 'Лучшие браузерные игры онлайн',
        meta_keywords TEXT DEFAULT 'игры, онлайн, бесплатно, webgl',
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`
    
    _, err := r.DB.Exec(query)
    return err
}

// GetConfig получает конфигурацию сайта
func (r *ConfigRepository) GetConfig() (*SiteConfig, error) {
    query := `SELECT id, site_name, logo_html, footer_logo_html, footer_text, footer_copyright, 
              meta_title, meta_description, meta_keywords, updated_at 
              FROM site_config LIMIT 1`
    
    var config SiteConfig
    err := r.DB.QueryRow(query).Scan(
        &config.ID, &config.SiteName, &config.LogoHTML, &config.FooterLogoHTML,
        &config.FooterText, &config.FooterCopyright,
        &config.MetaTitle, &config.MetaDescription, &config.MetaKeywords,
        &config.UpdatedAt,
    )
    
    if err == sql.ErrNoRows {
        return r.createDefaultConfig()
    }
    
    return &config, err
}

// createDefaultConfig создает конфигурацию по умолчанию
func (r *ConfigRepository) createDefaultConfig() (*SiteConfig, error) {
    query := `
    INSERT INTO site_config (site_name, logo_html, footer_logo_html, footer_text, footer_copyright, 
                             meta_title, meta_description, meta_keywords)
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
    RETURNING id, updated_at`
    
    defaultLogo := `<div class="header-logo-icon"><i class="fas fa-gamepad"></i></div><div class="header-logo-text">igro<span>play</span></div>`
    defaultFooterLogo := `<h3>igro<span>play</span></h3>`
    
    var config SiteConfig
    err := r.DB.QueryRow(query, 
        "igroplay.ru", 
        defaultLogo,
        defaultFooterLogo,
        "Лучший каталог браузерных игр. Играй бесплатно онлайн!",
        "© 2024 igroplay.ru. Все права защищены.",
        "Игры онлайн",
        "Лучшие браузерные игры онлайн",
        "игры, онлайн, бесплатно, webgl",
    ).Scan(&config.ID, &config.UpdatedAt)
    
    if err != nil {
        return nil, err
    }
    
    config.SiteName = "igroplay.ru"
    config.LogoHTML = defaultLogo
    config.FooterLogoHTML = defaultFooterLogo
    config.FooterText = "Лучший каталог браузерных игр. Играй бесплатно онлайн!"
    config.FooterCopyright = "© 2024 igroplay.ru. Все права защищены."
    config.MetaTitle = "Игры онлайн"
    config.MetaDescription = "Лучшие браузерные игры онлайн"
    config.MetaKeywords = "игры, онлайн, бесплатно, webgl"
    
    return &config, nil
}

// UpdateConfig обновляет конфигурацию сайта
func (r *ConfigRepository) UpdateConfig(config *SiteConfig) error {
    query := `
    UPDATE site_config SET 
        site_name = $1,
        logo_html = $2,
        footer_logo_html = $3,
        footer_text = $4,
        footer_copyright = $5,
        meta_title = $6,
        meta_description = $7,
        meta_keywords = $8,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = $9`
    
    _, err := r.DB.Exec(query,
        config.SiteName, config.LogoHTML, config.FooterLogoHTML,
        config.FooterText, config.FooterCopyright,
        config.MetaTitle, config.MetaDescription, config.MetaKeywords,
        config.ID,
    )
    
    return err
}