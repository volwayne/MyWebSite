package models

import (
    "database/sql"
    "fmt"
    "strconv"
    "time"
)

// Game представляет модель WebGL игры
type Game struct {
    ID          int       `json:"id"`
    Title       string    `json:"title"`
    Description string    `json:"description"`
    Category    string    `json:"category"`
    FilePath    string    `json:"file_path"`     // Путь к распакованной игре
    ZipFile     string    `json:"zip_file"`      // Имя ZIP файла
    ImageURL    string    `json:"image_url"`
    Thumbnail   string    `json:"thumbnail"`
    Width       int       `json:"width"`
    Height      int       `json:"height"`
    Plays       int       `json:"plays"`
    Rating      float64   `json:"rating"`
    CreatedAt   time.Time `json:"created_at"`
    UpdatedAt   time.Time `json:"updated_at"`
}

// User представляет модель пользователя
type User struct {
    ID        int       `json:"id"`
    Username  string    `json:"username"`
    Password  string    `json:"-"`
    Email     string    `json:"email"`
    Avatar    string    `json:"avatar"`
    Balance   int       `json:"balance"`
    Role      string    `json:"role"`
    CreatedAt time.Time `json:"created_at"`
}

// GameFilter параметры фильтрации игр
type GameFilter struct {
    Category string
    Search   string
    SortBy   string
    Page     int
    PageSize int
}

// GameRepository репозиторий для работы с играми
type GameRepository struct {
    DB *sql.DB
}

func NewGameRepository(db *sql.DB) *GameRepository {
    return &GameRepository{DB: db}
}

// ============================================
// МЕТОДЫ ДЛЯ СОЗДАНИЯ ТАБЛИЦ
// ============================================

func (r *GameRepository) CreateGamesTable() error {
    query := `
    CREATE TABLE IF NOT EXISTS games (
        id SERIAL PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        category VARCHAR(100),
        file_path TEXT NOT NULL,
        zip_file TEXT DEFAULT '',
        image_url TEXT,
        thumbnail TEXT,
        width INTEGER DEFAULT 800,
        height INTEGER DEFAULT 600,
        plays INTEGER DEFAULT 0,
        rating DECIMAL(3,2) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`
    
    _, err := r.DB.Exec(query)
    return err
}

func (r *GameRepository) CreateUsersTable() error {
    query := `
    CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        email VARCHAR(255),
        avatar TEXT DEFAULT '',
        balance INTEGER DEFAULT 100,
        role VARCHAR(50) DEFAULT 'user',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`
    
    _, err := r.DB.Exec(query)
    return err
}

// ============================================
// CRUD ОПЕРАЦИИ ДЛЯ ИГР
// ============================================

func (r *GameRepository) CreateGame(game *Game) error {
    query := `
    INSERT INTO games (title, description, category, file_path, zip_file, image_url, thumbnail, width, height, plays, rating)
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
    RETURNING id, created_at, updated_at`
    
    err := r.DB.QueryRow(query, game.Title, game.Description, game.Category,
        game.FilePath, game.ZipFile, game.ImageURL, game.Thumbnail,
        game.Width, game.Height, game.Plays, game.Rating).Scan(&game.ID, &game.CreatedAt, &game.UpdatedAt)
    
    return err
}

func (r *GameRepository) GetGameByID(id int) (*Game, error) {
    query := `SELECT id, title, description, category, file_path, zip_file, image_url, thumbnail, width, height, plays, rating, created_at, updated_at 
              FROM games WHERE id = $1`
    
    var game Game
    var thumbnail sql.NullString
    var zipFile sql.NullString
    
    err := r.DB.QueryRow(query, id).Scan(
        &game.ID, &game.Title, &game.Description, &game.Category,
        &game.FilePath, &zipFile, &game.ImageURL, &thumbnail,
        &game.Width, &game.Height, &game.Plays, &game.Rating,
        &game.CreatedAt, &game.UpdatedAt,
    )
    
    if err != nil {
        return nil, err
    }
    
    if thumbnail.Valid {
        game.Thumbnail = thumbnail.String
    } else {
        game.Thumbnail = ""
    }
    
    if zipFile.Valid {
        game.ZipFile = zipFile.String
    } else {
        game.ZipFile = ""
    }
    
    return &game, nil
}

func (r *GameRepository) ListGames(filter GameFilter) ([]Game, int, error) {
    offset := (filter.Page - 1) * filter.PageSize
    
    query := `SELECT id, title, description, category, file_path, zip_file, image_url, thumbnail, width, height, plays, rating, created_at, updated_at 
              FROM games WHERE 1=1`
    countQuery := `SELECT COUNT(*) FROM games WHERE 1=1`
    args := []interface{}{}
    argCount := 1
    
    if filter.Category != "" {
        query += " AND category = $" + strconv.Itoa(argCount)
        countQuery += " AND category = $" + strconv.Itoa(argCount)
        args = append(args, filter.Category)
        argCount++
    }
    
    if filter.Search != "" {
        query += " AND (title ILIKE $" + strconv.Itoa(argCount) + " OR description ILIKE $" + strconv.Itoa(argCount) + ")"
        countQuery += " AND (title ILIKE $" + strconv.Itoa(argCount) + " OR description ILIKE $" + strconv.Itoa(argCount) + ")"
        searchPattern := "%" + filter.Search + "%"
        args = append(args, searchPattern)
        argCount++
    }
    
    switch filter.SortBy {
    case "plays":
        query += " ORDER BY plays DESC"
    case "rating":
        query += " ORDER BY rating DESC"
    case "newest":
        query += " ORDER BY created_at DESC"
    default:
        query += " ORDER BY id DESC"
    }
    
    query += " LIMIT $" + strconv.Itoa(argCount) + " OFFSET $" + strconv.Itoa(argCount+1)
    args = append(args, filter.PageSize, offset)
    
    rows, err := r.DB.Query(query, args...)
    if err != nil {
        return nil, 0, err
    }
    defer rows.Close()
    
    var games []Game
    for rows.Next() {
        var game Game
        var thumbnail sql.NullString
        var zipFile sql.NullString
        
        err := rows.Scan(&game.ID, &game.Title, &game.Description, &game.Category,
            &game.FilePath, &zipFile, &game.ImageURL, &thumbnail,
            &game.Width, &game.Height, &game.Plays, &game.Rating,
            &game.CreatedAt, &game.UpdatedAt)
        if err != nil {
            return nil, 0, err
        }
        
        if thumbnail.Valid {
            game.Thumbnail = thumbnail.String
        } else {
            game.Thumbnail = ""
        }
        
        if zipFile.Valid {
            game.ZipFile = zipFile.String
        } else {
            game.ZipFile = ""
        }
        
        games = append(games, game)
    }
    
    var total int
    err = r.DB.QueryRow(countQuery, args[:len(args)-2]...).Scan(&total)
    if err != nil {
        return nil, 0, err
    }
    
    return games, total, nil
}

func (r *GameRepository) IncrementGamePlays(id int) error {
    query := `UPDATE games SET plays = plays + 1, updated_at = CURRENT_TIMESTAMP WHERE id = $1`
    _, err := r.DB.Exec(query, id)
    return err
}

func (r *GameRepository) UpdateGame(game *Game) error {
    query := `UPDATE games SET title=$1, description=$2, category=$3, file_path=$4, zip_file=$5, image_url=$6, thumbnail=$7, width=$8, height=$9, rating=$10, updated_at=CURRENT_TIMESTAMP 
              WHERE id=$11`
    _, err := r.DB.Exec(query, game.Title, game.Description, game.Category,
        game.FilePath, game.ZipFile, game.ImageURL, game.Thumbnail,
        game.Width, game.Height, game.Rating, game.ID)
    return err
}

func (r *GameRepository) DeleteGame(id int) error {
    query := `DELETE FROM games WHERE id=$1`
    _, err := r.DB.Exec(query, id)
    return err
}

// ============================================
// МЕТОДЫ ДЛЯ РАБОТЫ С ПОЛЬЗОВАТЕЛЯМИ
// ============================================

func (r *GameRepository) CreateUser(user *User) error {
    query := `
    INSERT INTO users (username, password, email, avatar, balance, role)
    VALUES ($1, $2, $3, $4, $5, $6)
    RETURNING id, created_at`
    
    err := r.DB.QueryRow(query, user.Username, user.Password, user.Email, user.Avatar, user.Balance, user.Role).Scan(&user.ID, &user.CreatedAt)
    return err
}

func (r *GameRepository) GetUserByUsername(username string) (*User, error) {
    query := `SELECT id, username, password, email, avatar, balance, role, created_at FROM users WHERE username = $1`
    
    var user User
    err := r.DB.QueryRow(query, username).Scan(
        &user.ID, &user.Username, &user.Password, &user.Email, &user.Avatar, &user.Balance, &user.Role, &user.CreatedAt,
    )
    
    if err != nil {
        if err == sql.ErrNoRows {
            return nil, fmt.Errorf("user not found")
        }
        return nil, err
    }
    
    return &user, nil
}

func (r *GameRepository) GetUserByID(id int) (*User, error) {
    query := `SELECT id, username, password, email, avatar, balance, role, created_at FROM users WHERE id = $1`
    
    var user User
    err := r.DB.QueryRow(query, id).Scan(
        &user.ID, &user.Username, &user.Password, &user.Email, &user.Avatar, &user.Balance, &user.Role, &user.CreatedAt,
    )
    
    if err != nil {
        if err == sql.ErrNoRows {
            return nil, fmt.Errorf("user not found")
        }
        return nil, err
    }
    
    return &user, nil
}

func (r *GameRepository) UpdateUserPassword(userID int, newPassword string) error {
    query := `UPDATE users SET password = $1 WHERE id = $2`
    _, err := r.DB.Exec(query, newPassword, userID)
    return err
}

func (r *GameRepository) UpdateUserBalance(userID int, newBalance int) error {
    query := `UPDATE users SET balance = $1 WHERE id = $2`
    _, err := r.DB.Exec(query, newBalance, userID)
    return err
}

func (r *GameRepository) AddToUserBalance(userID int, amount int) error {
    query := `UPDATE users SET balance = balance + $1 WHERE id = $2`
    _, err := r.DB.Exec(query, amount, userID)
    return err
}